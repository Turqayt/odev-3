﻿/****************************************************************************
**
**				ÖĞRENCİ ADI...........................:Turgay Teymurov
**				ÖĞRENCİ NUMARASI.............:G191210552
**				DERS GRUBU…………………:2A
****************************************************************************/
#include <iostream>
#include <time.h>
#include <Windows.h>
using namespace std;
void koordinatAta(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;

	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
};
struct Sahne
{
	int genislig;
	int yukseklik;
	char karakter;
};
struct LSekli
{
	int x;
	int y;
	int boyut;
	char karakter;
};
Sahne sahneOlustur();
void sahneCiz(Sahne);
LSekli lSekliOlustur();
void lSekliCiz(LSekli);
LSekli lSekliAsagiGotur(LSekli);
int main()
{
	srand(time(0));
	Sahne sahne;
	LSekli sekli;
	sahne = sahneOlustur();
	sekli = lSekliOlustur();
	//işlemin sonsuza kadar dönmesi için
	while(true)
	{
		system("cls");
		sahneCiz(sahne);
		lSekliCiz(sekli);
        sekli =lSekliAsagiGotur(sekli);
		//islem yükseklik eksi bir  kadar aşağı indikde Lsekli tekrar sıfırlanır
		if (sekli.y + sekli.boyut == sahne.yukseklik-1)
			sekli = lSekliOlustur();
		Sleep(100);
	}
}
Sahne sahneOlustur()
{
	Sahne cizim;
	char karekter[] = { '*','#','$','+','@' };
	cizim.genislig = (rand() % 3 + 3) * 10;
	cizim.yukseklik = (rand() % 2 + 2) * 10;
	cizim.karakter = karekter[rand() % 5];
	return cizim;
}
void sahneCiz(Sahne cizim)
{
	//sahnenin üstünü çiziyor
	for (int i = 0; i < cizim.genislig ; i++)
		cout << cizim.karakter;
	//sahnenin sağ tarafını ciziyor
	for (int i = 0; i < cizim.yukseklik; i++)
	{
		koordinatAta(cizim.genislig , i);
		cout << cizim.karakter;
	}
	//sahnenin alt tarafını çiziyor
	for (int i = 0; i < cizim.genislig; i++)
	{
		koordinatAta(cizim.genislig - 1-i, cizim.yukseklik-1);
		cout << cizim.karakter;
	}
	//sahnenin sol tarafını ciziyor
	for (int i = 0; i < cizim.yukseklik; i++)
	{
		koordinatAta(0, cizim.yukseklik-i-1);
		cout << cizim.karakter;
	}
}
LSekli lSekliOlustur()
{
	LSekli LCizim;
	char karakter[5] = { '*','#','$','+','@' };
	LCizim.x = rand() % 19 + 6;
	LCizim.y = 3;
	LCizim.boyut = rand() % 4 + 3;
	LCizim.karakter = karakter[rand() % 5];
	return LCizim;
}
void lSekliCiz(LSekli LCizim)
{
	//L seklin en üst tarafını çiziyor
	for(int i=0;i<(LCizim.boyut+1)/2;i++)
	{
		LCizim.x++;
		koordinatAta(LCizim.x, LCizim.y);
		cout << LCizim.karakter;
	}
	//L seklin sağ en uzun tarafını ciziyor
	for (int i = 0; i < LCizim.boyut / 2; i++)
	{
		LCizim.y++;
		koordinatAta(LCizim.x, LCizim.y);
		cout << LCizim.karakter;
	}
	//L seklin sağ üst tarafını çiziyor 
	for (int i = 0; i < LCizim.boyut / 2; i++)
	{
		LCizim.x++;
		koordinatAta(LCizim.x, LCizim.y);
		cout << LCizim.karakter;
	}
	//L seklin sağ küçük tarafını çiziyor
	for (int i = 0; i <( LCizim.boyut+1) / 2; i++)
	{
		LCizim.y++;
		koordinatAta(LCizim.x, LCizim.y);
		cout << LCizim.karakter;
	}
	//L seklin alt tarafını çiziyor
	for (int i = 0; i < LCizim.boyut -1; i++)
	{
		LCizim.x--;
		koordinatAta(LCizim.x, LCizim.y);
		cout << LCizim.karakter;
	}
	//L seklin sol tarafını çiziyor
	for (int i = 0; i < LCizim.boyut -1; i++)
	{
		LCizim.y--;
		koordinatAta(LCizim.x, LCizim.y);
		cout << LCizim.karakter;
	}
	
}
LSekli lSekliAsagiGotur(LSekli LCizim)
{
	LCizim.y++;
	return LCizim;
}